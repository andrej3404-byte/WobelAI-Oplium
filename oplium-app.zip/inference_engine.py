"""inference_engine.py - model loading, streaming generation and web search for Oplium."""
import html
import json
import os
import re
import threading
import time
import traceback
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

from config_hub import DATA_DIR, IDENTITY_SHOTS, MODEL_REGISTRY

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)


# --------------------------------------------------------------------------- #
# Web search
# --------------------------------------------------------------------------- #
def _clean_html(raw: str) -> str:
    raw = re.sub(r"(?is)<(script|style|noscript|svg|header|footer|nav)\b.*?</\1>", " ", raw)
    raw = re.sub(r"(?s)<[^>]+>", " ", raw)
    raw = html.unescape(raw)
    return re.sub(r"\s+", " ", raw).strip()


def _ddg_library(query: str, n: int):
    try:
        from ddgs import DDGS  # pip install ddgs
    except ImportError:
        from duckduckgo_search import DDGS  # older package name
    with DDGS() as d:
        found = list(d.text(query, max_results=n))
    return [
        {
            "title": r.get("title", ""),
            "url": r.get("href") or r.get("url", ""),
            "snippet": r.get("body", ""),
        }
        for r in found
    ]


def _ddg_html(query: str, n: int):
    """Fallback that needs no extra package."""
    data = urllib.parse.urlencode({"q": query}).encode()
    req = urllib.request.Request(
        "https://html.duckduckgo.com/html/", data=data, headers={"User-Agent": USER_AGENT}
    )
    page = urllib.request.urlopen(req, timeout=12).read().decode("utf-8", "ignore")
    links = re.findall(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>', page, re.S)
    snippets = re.findall(r'<a[^>]+class="result__snippet"[^>]*>(.*?)</a>', page, re.S)
    out = []
    for i, (href, title) in enumerate(links[:n]):
        if "uddg=" in href:
            href = urllib.parse.unquote(href.split("uddg=")[1].split("&")[0])
        elif href.startswith("//"):
            href = "https:" + href
        out.append(
            {
                "title": _clean_html(title),
                "url": href,
                "snippet": _clean_html(snippets[i]) if i < len(snippets) else "",
            }
        )
    return out


def web_search(query: str, n: int = 5):
    query = query.strip()[:160]
    for backend in (_ddg_library, _ddg_html):
        try:
            results = backend(query, n)
            if results:
                return results
        except Exception:
            continue
    return []


def fetch_page_text(url: str, max_chars: int = 1500) -> str:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=6) as resp:
            ctype = resp.headers.get("Content-Type", "")
            if "html" not in ctype and "text" not in ctype:
                return ""
            raw = resp.read(400_000).decode("utf-8", "ignore")
        return _clean_html(raw)[:max_chars]
    except Exception:
        return ""


# --------------------------------------------------------------------------- #
# Engine
# --------------------------------------------------------------------------- #
class OpliumInferenceManager:
    def __init__(self, app):
        self.app = app
        self.model = None
        self.tokenizer = None
        self.device = "cpu"
        self.model_ready = False
        self.loading_id = None
        self.active_model_id = next(iter(MODEL_REGISTRY.values()))
        self._stop = threading.Event()
        self._load_lock = threading.Lock()

    # ----- model loading ------------------------------------------------- #
    def async_mount_brain(self, model_id: str):
        if self.loading_id:
            return
        threading.Thread(target=self._load_model, args=(model_id,), daemon=True).start()

    def _find_adapter_config(self, model_id: str):
        try:
            if os.path.isdir(model_id):
                path = os.path.join(model_id, "adapter_config.json")
            else:
                from huggingface_hub import hf_hub_download

                path = hf_hub_download(model_id, "adapter_config.json")
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception:
            pass
        return None

    def _load_model(self, model_id: str):
        with self._load_lock:
            self.loading_id = model_id
            self.model_ready = False
            self.app.post(self.app.on_model_loading, model_id)
            try:
                import torch
                from transformers import AutoModelForCausalLM, AutoTokenizer

                self.device = "cuda" if torch.cuda.is_available() else "cpu"
                dtype = torch.float16 if self.device == "cuda" else torch.float32

                adapter_cfg = self._find_adapter_config(model_id)
                if adapter_cfg:
                    base_id = adapter_cfg["base_model_name_or_path"]
                    self.app.post(self.app.set_status, "Loading base model…", "busy")
                    tok = AutoTokenizer.from_pretrained(base_id)
                    model = AutoModelForCausalLM.from_pretrained(base_id, torch_dtype=dtype)
                    self.app.post(self.app.set_status, "Applying Oplium adapter…", "busy")
                    from peft import PeftModel

                    model = PeftModel.from_pretrained(model, model_id)
                    model = model.merge_and_unload()
                else:
                    self.app.post(self.app.set_status, "Loading model…", "busy")
                    tok = AutoTokenizer.from_pretrained(model_id)
                    model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=dtype)

                model.to(self.device).eval()
                self.model, self.tokenizer = model, tok
                self.active_model_id = model_id
                self.model_ready = True
                self.loading_id = None
                self.app.post(self.app.on_model_ready, model_id, self.device)
            except Exception as e:
                self.loading_id = None
                self.model_ready = False
                self.app.post(self.app.on_model_error, model_id, f"{type(e).__name__}: {e}")

    # ----- generation ---------------------------------------------------- #
    def stop(self):
        self._stop.set()

    def _build_web_context(self, query: str, n_results: int):
        results = web_search(query, n_results)
        if not results:
            return "", []
        # grab text from the top 2 pages in parallel
        with ThreadPoolExecutor(max_workers=2) as pool:
            pages = list(pool.map(lambda r: fetch_page_text(r["url"]), results[:2]))
        parts = []
        for i, r in enumerate(results, 1):
            block = f"[{i}] {r['title']} ({r['url']})\n{r['snippet']}"
            if i <= len(pages) and pages[i - 1]:
                block += f"\nExcerpt: {pages[i - 1]}"
            parts.append(block)
        context = "\n\n".join(parts)[:3800]
        return context, results

    def execute_token_math(self, chat_id: str, history: list, params: dict):
        """Runs in a worker thread. Streams text back to the UI via app.post()."""
        self._stop.clear()
        text, sources, error = "", [], None
        try:
            import torch
            from transformers import StoppingCriteria, StoppingCriteriaList, TextIteratorStreamer

            tok, model = self.tokenizer, self.model
            user_prompt = history[-1]["content"]

            system = params["system_prompt"]
            augmented = user_prompt
            if params["web_search"]:
                self.app.post(self.app.set_live_status, chat_id, "Searching the web")
                context, sources = self._build_web_context(user_prompt, params["web_results"])
                system += f" Today's date is {time.strftime('%Y-%m-%d')}."
                if context:
                    augmented = (
                        "Use these web search results to answer the question. "
                        "Cite sources like [1] or [2]. If the results do not contain the answer, say so.\n\n"
                        f"{context}\n\nQuestion: {user_prompt}"
                    )
                else:
                    augmented = (
                        "(Web search returned nothing, answer from your own knowledge and say that "
                        f"you could not check the web.)\n\n{user_prompt}"
                    )
                self.app.post(self.app.set_live_status, chat_id, "Thinking")

            messages = [{"role": "system", "content": system}]
            for q, a_ in IDENTITY_SHOTS:
                messages.append({"role": "user", "content": q})
                messages.append({"role": "assistant", "content": a_})
            for m in history[:-1][-8:]:
                if m["role"] in ("user", "assistant"):
                    messages.append({"role": m["role"], "content": m["content"]})
            messages.append({"role": "user", "content": augmented})

            prompt_text = tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            inputs = tok(prompt_text, return_tensors="pt")
            if inputs["input_ids"].shape[1] > 3072:  # keep the end of overly long prompts
                inputs = {k: v[:, -3072:] for k, v in inputs.items()}
            inputs = {k: v.to(self.device) for k, v in inputs.items()}

            stop_event = self._stop

            class StopOnFlag(StoppingCriteria):
                def __call__(self, input_ids, scores, **kwargs):
                    return torch.full(
                        (input_ids.shape[0],), stop_event.is_set(), dtype=torch.bool, device=input_ids.device
                    )

            streamer = TextIteratorStreamer(tok, skip_prompt=True, skip_special_tokens=True, timeout=180)
            temperature = max(0.05, float(params["temperature"]))
            gen_kwargs = dict(
                **inputs,
                streamer=streamer,
                max_new_tokens=int(params["max_tokens"]),
                do_sample=True,
                temperature=temperature,
                top_p=float(params["top_p"]),
                repetition_penalty=float(params["repetition_penalty"]),
                stopping_criteria=StoppingCriteriaList([StopOnFlag()]),
                pad_token_id=tok.pad_token_id if tok.pad_token_id is not None else tok.eos_token_id,
            )
            gen_errors = []

            def run():
                try:
                    with torch.inference_mode():
                        model.generate(**gen_kwargs)
                except Exception as e:
                    gen_errors.append(e)
                    streamer.on_finalized_text("", stream_end=True)

            worker = threading.Thread(target=run, daemon=True)
            worker.start()

            last_push = 0.0
            for piece in streamer:
                text += piece
                now = time.time()
                if now - last_push > 0.04:
                    self.app.post(self.app.on_stream, chat_id, text)
                    last_push = now
            worker.join()
            if gen_errors:
                raise gen_errors[0]
        except Exception as e:
            error = f"{type(e).__name__}: {e}"
            try:
                with open(os.path.join(DATA_DIR, "error.log"), "a", encoding="utf-8") as f:
                    f.write(time.strftime("%Y-%m-%d %H:%M:%S") + "\n" + traceback.format_exc() + "\n")
            except Exception:
                pass
        self.app.post(self.app.on_generation_done, chat_id, text.strip(), sources, error)
