"""config_hub.py - central settings for the WobelAI / Oplium desktop app."""
import os

APP_TITLE = "WobelAI - Oplium"
APP_VERSION = "1.4"

# Where chats and settings are stored (C:\Users\<you>\.wobelai)
DATA_DIR = os.path.join(os.path.expanduser("~"), ".wobelai")
os.makedirs(DATA_DIR, exist_ok=True)
CHATS_FILE = os.path.join(DATA_DIR, "chats.json")
SETTINGS_FILE = os.path.join(DATA_DIR, "settings.json")

SUPPORT_EMAIL = "wobelaiofficial@gmail.com"
SUPPORT_YOUTUBE = "youtube.com/@WobelAI"
SUPPORT_WEBSITE = "https://andrej3404.wixsite.com/wobelai"

# Display name -> Hugging Face repo id OR a local folder path.
# LoRA adapters are detected automatically (adapter_config.json) and merged onto their base model.
MODEL_REGISTRY = {
    "Oplium 1.4": "Andreeejs/Oplium-1.4-330M",
    "Qwen2.5 0.5B Instruct (base)": "Qwen/Qwen2.5-0.5B-Instruct",
}

# Older defaults that get upgraded automatically if they are still saved in settings.json
LEGACY_SYSTEM_PROMPTS = [
    "You are Oplium, a helpful AI assistant made by WobelAI. "
    "Answer clearly and concisely. If you are not sure about something, say so."
]

DEFAULT_SYSTEM_PROMPT = (
    "You are Oplium, an AI assistant developed by WobelAI. Your name is Oplium and your creator is WobelAI. "
    "If someone asks who you are or who made you, answer that you are Oplium, made by WobelAI. "
    "Never say that you are Qwen or that you were made by Alibaba Cloud. "
    "Answer clearly and concisely. If you are not sure about something, say so."
)

# Hidden example turns placed before every chat. Small models follow examples far better than rules.
IDENTITY_SHOTS = [
    ("Who are you?", "I'm Oplium, an AI assistant developed by WobelAI. How can I help you?"),
    ("Who created you?", "I was created by WobelAI."),
]

DEFAULT_SETTINGS = {
    "max_tokens": 400,
    "temperature": 0.5,
    "top_p": 0.9,
    "repetition_penalty": 1.1,
    "web_search": False,
    "web_results": 5,
    "system_prompt": DEFAULT_SYSTEM_PROMPT,
    "last_model": "",
    "custom_models": {},
}

SUGGESTIONS = [
    "Explain how a neural network learns, in simple words",
    "Write a short Python function that reverses a string",
    "Give me 5 name ideas for a gaming YouTube channel",
    "What are the latest news today? (turn on Web search)",
]

FONT = "Segoe UI"

# Neutral black / grey base with one emerald accent (your brand colour).
COLORS = {
    "bg": "#0d0d0d",
    "sidebar": "#080808",
    "panel": "#141414",
    "card": "#1a1a1a",
    "card_hover": "#242424",
    "border": "#2b2b2b",
    "text": "#ececec",
    "muted": "#9a9a9a",
    "faint": "#666666",
    "accent": "#10b981",
    "accent_hover": "#0ea371",
    "accent_text": "#04130d",
    "user_bubble": "#262626",
    "danger": "#ef4444",
    "warn": "#f59e0b",
    "link": "#60a5fa",
}
