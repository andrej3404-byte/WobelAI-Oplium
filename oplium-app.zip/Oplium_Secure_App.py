import json
import os
import queue
import threading
import time
import tkinter as tk
import traceback
import webbrowser
from tkinter import filedialog
from urllib.parse import urlparse

import customtkinter as ctk

import config_hub as cfg
from config_hub import COLORS as C, FONT, MODEL_REGISTRY, SUPPORT_EMAIL, SUPPORT_WEBSITE, SUPPORT_YOUTUBE
from inference_engine import OpliumInferenceManager


def font(size=13, weight="normal", **kw):
    return ctk.CTkFont(family=FONT, size=size, weight=weight, **kw)


class WobelAIFlagshipPortal(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        self.title(cfg.APP_TITLE)
        self.geometry("1280x820")
        self.minsize(980, 660)
        self.configure(fg_color=C["bg"])

        # ---------- state ----------
        self.ui_queue = queue.Queue()
        self.settings = {**cfg.DEFAULT_SETTINGS, **self._load_json(cfg.SETTINGS_FILE, {})}
        if self.settings.get("system_prompt") in cfg.LEGACY_SYSTEM_PROMPTS:
            self.settings["system_prompt"] = cfg.DEFAULT_SYSTEM_PROMPT
        for name, path in self.settings.get("custom_models", {}).items():
            MODEL_REGISTRY[name] = path
        self.chats = self._load_json(cfg.CHATS_FILE, {})
        if not self.chats:
            self._new_chat_record()
        self.current_id = list(self.chats.keys())[-1]
        self.current_view = "chat"

        self.generating = False
        self.generating_chat = None
        self.live_label = None
        self.live_text = ""
        self.live_status = "Thinking"
        self.wrap = 720
        self._resize_job = None
        self._save_job = None
        self._scroll_job = None

        self.web_var = tk.BooleanVar(value=bool(self.settings["web_search"]))

        # ---------- engine ----------
        self.engine = OpliumInferenceManager(self)
        if self.settings.get("last_model") in MODEL_REGISTRY.values():
            self.engine.active_model_id = self.settings["last_model"]

        # ---------- layout ----------
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self._build_sidebar()

        self.canvas_view = ctk.CTkFrame(self, corner_radius=0, fg_color="transparent")
        self.canvas_view.grid(row=0, column=1, sticky="nsew")
        self.canvas_view.grid_rowconfigure(0, weight=1)
        self.canvas_view.grid_columnconfigure(0, weight=1)

        self._build_chat_panel()
        self.models_panel = ctk.CTkFrame(self.canvas_view, fg_color=C["panel"], corner_radius=16)
        self.settings_panel = ctk.CTkFrame(self.canvas_view, fg_color=C["panel"], corner_radius=16)
        self.support_panel = ctk.CTkFrame(self.canvas_view, fg_color=C["panel"], corner_radius=16)
        self._build_models_panel()
        self._build_settings_panel()
        self._build_support_panel()

        self.render_sidebar_cards()
        self.refresh_message_stream()

        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(30, self._drain)
        self.engine.async_mount_brain(self.engine.active_model_id)

    # ------------------------------------------------------------------ #
    # Thread-safe UI bridge
    # ------------------------------------------------------------------ #
    def post(self, fn, *args):
        """Called from worker threads; runs fn(*args) on the UI thread."""
        self.ui_queue.put((fn, args))

    def _drain(self):
        try:
            while True:
                fn, args = self.ui_queue.get_nowait()
                try:
                    fn(*args)
                except tk.TclError:
                    pass
                except Exception:
                    traceback.print_exc()
        except queue.Empty:
            pass
        self.after(30, self._drain)

    # ------------------------------------------------------------------ #
    # Persistence
    # ------------------------------------------------------------------ #
    @staticmethod
    def _load_json(path, default):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return default

    def _save_json(self, path, data):
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            traceback.print_exc()

    def save_chats(self):
        self._save_json(cfg.CHATS_FILE, self.chats)

    def save_settings(self):
        self._save_json(cfg.SETTINGS_FILE, self.settings)

    def _schedule_save(self):
        if self._save_job:
            self.after_cancel(self._save_job)
        self._save_job = self.after(400, self.save_settings)

    def _on_close(self):
        self.save_chats()
        self.save_settings()
        self.destroy()

    def _new_chat_record(self):
        cid = str(int(time.time() * 1000))
        self.chats[cid] = {"title": "New chat", "messages": []}
        return cid

    # ------------------------------------------------------------------ #
    # Sidebar
    # ------------------------------------------------------------------ #
    def _build_sidebar(self):
        sb = ctk.CTkFrame(self, width=280, corner_radius=0, fg_color=C["sidebar"])
        sb.grid(row=0, column=0, sticky="nsew")
        sb.grid_propagate(False)
        sb.grid_rowconfigure(3, weight=1)
        self.sidebar_frame = sb

        ctk.CTkLabel(sb, text="WobelAI", font=font(24, "bold"), text_color=C["accent"]).grid(
            row=0, column=0, padx=22, pady=(30, 0), sticky="w"
        )
        ctk.CTkLabel(sb, text=f"Oplium {cfg.APP_VERSION}", font=font(12), text_color=C["faint"]).grid(
            row=1, column=0, padx=23, pady=(0, 18), sticky="w"
        )
        ctk.CTkButton(
            sb, text="+  New chat", height=40, corner_radius=10, fg_color=C["accent"],
            hover_color=C["accent_hover"], text_color=C["accent_text"], font=font(13, "bold"),
            command=self.create_fresh_chat,
        ).grid(row=2, column=0, padx=16, pady=(0, 12), sticky="ew")

        self.scroll_sessions = ctk.CTkScrollableFrame(
            sb, fg_color="transparent", label_text="Chats", label_text_color=C["faint"],
            label_font=font(11), scrollbar_button_color=C["card"],
        )
        self.scroll_sessions.grid(row=3, column=0, sticky="nsew", padx=8)

        footer = ctk.CTkFrame(sb, fg_color="transparent")
        footer.grid(row=4, column=0, sticky="ew", padx=14, pady=(8, 18))
        self.nav_buttons = {}
        for key, label, cmd in (
            ("models", "Models", self.show_models_frame),
            ("settings", "Settings", self.show_settings_frame),
            ("support", "Support", self.show_support_frame),
        ):
            b = ctk.CTkButton(
                footer, text=label, anchor="w", height=36, corner_radius=8, fg_color="transparent",
                hover_color=C["card"], text_color=C["muted"], font=font(13), command=cmd,
            )
            b.pack(fill=tk.X, pady=2)
            self.nav_buttons[key] = b

    def render_sidebar_cards(self):
        for child in self.scroll_sessions.winfo_children():
            child.destroy()
        for cid in reversed(list(self.chats.keys())):
            active = cid == self.current_id and self.current_view == "chat"
            row = ctk.CTkFrame(self.scroll_sessions, fg_color=C["card"] if active else "transparent", corner_radius=8)
            row.pack(fill=tk.X, pady=2, padx=2)
            ctk.CTkButton(
                row, text=self.chats[cid]["title"], anchor="w", height=36, corner_radius=8,
                fg_color="transparent", hover_color=C["card_hover"],
                text_color=C["text"] if active else C["muted"], font=font(13, "bold" if active else "normal"),
                command=lambda t=cid: self.switch_session(t),
            ).pack(side=tk.LEFT, fill=tk.X, expand=True)
            ctk.CTkButton(
                row, text="✕", width=28, height=28, corner_radius=6, fg_color="transparent",
                hover_color=C["border"], text_color=C["faint"], font=font(11),
                command=lambda t=cid: self.delete_chat(t),
            ).pack(side=tk.RIGHT, padx=(0, 4))

    # ------------------------------------------------------------------ #
    # Chat panel
    # ------------------------------------------------------------------ #
    def _build_chat_panel(self):
        cp = ctk.CTkFrame(self.canvas_view, fg_color="transparent")
        cp.grid(row=0, column=0, sticky="nsew")
        cp.grid_rowconfigure(1, weight=1)
        cp.grid_columnconfigure(0, weight=1)
        cp.bind("<Configure>", self._on_resize)
        self.chat_panel = cp

        # top bar
        top = ctk.CTkFrame(cp, fg_color="transparent", height=56)
        top.grid(row=0, column=0, sticky="ew", padx=36, pady=(14, 0))
        top.grid_columnconfigure(0, weight=1)
        self.chat_title_label = ctk.CTkLabel(top, text="", font=font(15, "bold"), text_color=C["text"], anchor="w")
        self.chat_title_label.grid(row=0, column=0, sticky="w")
        self.web_switch = ctk.CTkSwitch(
            top, text="Web search", variable=self.web_var, command=self._on_web_toggle,
            progress_color=C["accent"], font=font(12), text_color=C["muted"],
        )
        self.web_switch.grid(row=0, column=1, padx=(0, 18))
        self.status_label = ctk.CTkLabel(
            top, text="  Starting…", font=font(12), text_color=C["warn"], fg_color=C["card"],
            corner_radius=12, height=26,
        )
        self.status_label.grid(row=0, column=2)

        # messages
        self.message_viewport = ctk.CTkScrollableFrame(
            cp, fg_color="transparent", scrollbar_button_color=C["card"],
            scrollbar_button_hover_color=C["border"],
        )
        self.message_viewport.grid(row=1, column=0, sticky="nsew", padx=(36, 20), pady=(8, 8))

        # input
        dock = ctk.CTkFrame(cp, fg_color=C["card"], corner_radius=18, border_width=1, border_color=C["border"])
        dock.grid(row=2, column=0, sticky="ew", padx=36, pady=(4, 6))
        dock.grid_columnconfigure(0, weight=1)
        self.input_dock = dock

        self.user_entry = ctk.CTkTextbox(
            dock, height=48, fg_color="transparent", text_color=C["text"], font=font(14),
            border_width=0, wrap="word", activate_scrollbars=False,
        )
        self.user_entry.grid(row=0, column=0, sticky="ew", padx=(16, 6), pady=8)
        self.user_entry.bind("<Return>", self._on_enter)
        self.user_entry.bind("<Shift-Return>", lambda e: None)
        self.user_entry.bind("<KeyRelease>", lambda e: self._resize_input())

        self.send_btn = ctk.CTkButton(
            dock, text="Send", width=82, height=38, corner_radius=12, fg_color=C["accent"],
            hover_color=C["accent_hover"], text_color=C["accent_text"], font=font(13, "bold"),
            command=self.start_inference_thread,
        )
        self.send_btn.grid(row=0, column=1, padx=(0, 10), pady=8, sticky="s")

        ctk.CTkLabel(
            cp, text="Enter to send  ·  Shift+Enter for a new line  ·  Oplium can make mistakes",
            font=font(11), text_color=C["faint"],
        ).grid(row=3, column=0, pady=(0, 12))

    def _on_enter(self, event):
        self.start_inference_thread()
        return "break"

    def _resize_input(self):
        lines = int(self.user_entry.index("end-1c").split(".")[0])
        self.user_entry.configure(height=min(max(48, 22 * lines + 14), 150))

    def _on_resize(self, event):
        new_wrap = max(360, event.width - 230)
        if abs(new_wrap - self.wrap) < 40:
            return
        self.wrap = new_wrap
        if self._resize_job:
            self.after_cancel(self._resize_job)
        self._resize_job = self.after(200, self.refresh_message_stream)

    def _on_web_toggle(self):
        self.settings["web_search"] = bool(self.web_var.get())
        self._schedule_save()

    # ----- status pill ---------------------------------------------------- #
    def set_status(self, text, kind="ok"):
        color = {"ok": C["accent"], "busy": C["warn"], "error": C["danger"]}.get(kind, C["muted"])
        self.status_label.configure(text=f"  ●  {text}  ", text_color=color)

    def model_title(self, model_id):
        for title, mid in MODEL_REGISTRY.items():
            if mid == model_id:
                return title
        return os.path.basename(model_id.rstrip("/\\")) or model_id

    # ----- message rendering ---------------------------------------------- #
    def refresh_message_stream(self):
        try:
            self.message_viewport._parent_canvas.yview_moveto(0)
        except Exception:
            pass
        for child in self.message_viewport.winfo_children():
            child.destroy()
        self.live_label = None
        chat = self.chats[self.current_id]
        self.chat_title_label.configure(text=chat["title"])
        try:
            if not chat["messages"]:
                self._render_welcome()
            for m in chat["messages"]:
                self._render_message(m)
            if self.generating and self.generating_chat == self.current_id:
                self._render_live_card()
        except Exception:
            traceback.print_exc()
            ctk.CTkLabel(
                self.message_viewport, text="Could not draw this chat:\n" + traceback.format_exc().splitlines()[-1],
                font=font(12), text_color=C["danger"], wraplength=self.wrap, justify="left",
            ).pack(pady=20)
        self._scroll_bottom()

    def _scroll_bottom(self):
        """Refresh the scroll region first, otherwise the view can stay scrolled past the new content."""
        def go():
            self._scroll_job = None
            try:
                canvas = self.message_viewport._parent_canvas
                self.message_viewport.update_idletasks()
                bbox = canvas.bbox("all")
                if bbox:
                    canvas.configure(scrollregion=bbox)
                    if bbox[3] - bbox[1] <= canvas.winfo_height():
                        canvas.yview_moveto(0)
                    else:
                        canvas.yview_moveto(1.0)
            except Exception:
                pass

        if self._scroll_job is None:
            self._scroll_job = self.after(50, go)
        self.after(300, go)

    def _render_welcome(self):
        box = ctk.CTkFrame(self.message_viewport, fg_color="transparent")
        box.pack(fill=tk.X, pady=(70, 0))
        ctk.CTkLabel(box, text="What can Oplium help you with?", font=font(28, "bold"), text_color=C["text"]).pack()
        ctk.CTkLabel(
            box, text="Ask a question, or turn on Web search to let Oplium look things up.",
            font=font(13), text_color=C["muted"],
        ).pack(pady=(6, 28))
        grid = ctk.CTkFrame(box, fg_color="transparent")
        grid.pack()
        for i, s in enumerate(cfg.SUGGESTIONS):
            ctk.CTkButton(
                grid, text=s, width=300, height=64, corner_radius=12, fg_color=C["card"],
                hover_color=C["card_hover"], text_color=C["text"], font=font(12), anchor="w",
                border_width=1, border_color=C["border"], command=lambda t=s: self._use_suggestion(t),
            ).grid(row=i // 2, column=i % 2, padx=6, pady=6)
            # let long suggestions wrap inside the button
            grid.winfo_children()[-1]._text_label.configure(wraplength=260, justify="left")

    def _use_suggestion(self, text):
        self.user_entry.delete("1.0", "end")
        self.user_entry.insert("1.0", text)
        self.start_inference_thread()

    def _render_message(self, m):
        role = m["role"]
        if role == "system":
            ctk.CTkLabel(
                self.message_viewport, text=m["content"], font=font(12), text_color=C["danger"],
                wraplength=self.wrap, justify="left",
            ).pack(pady=8)
        elif role == "user":
            row = ctk.CTkFrame(self.message_viewport, fg_color="transparent")
            row.pack(fill=tk.X, pady=8)
            bubble = ctk.CTkFrame(row, fg_color=C["user_bubble"], corner_radius=16)
            bubble.pack(side=tk.RIGHT, padx=(60, 6))
            ctk.CTkLabel(
                bubble, text=m["content"], font=font(14), text_color=C["text"], justify="left",
                wraplength=int(self.wrap * 0.75),
            ).pack(padx=16, pady=10)
        else:
            self._assistant_card(m["content"], m.get("sources", []))

    def _assistant_card(self, text, sources, live=False):
        row = ctk.CTkFrame(self.message_viewport, fg_color="transparent")
        row.pack(fill=tk.X, pady=10)
        avatar = ctk.CTkFrame(row, width=32, height=32, corner_radius=16, fg_color=C["accent"])
        avatar.pack(side=tk.LEFT, anchor="n", padx=(6, 12))
        avatar.pack_propagate(False)
        ctk.CTkLabel(avatar, text="O", font=font(14, "bold"), text_color=C["accent_text"]).pack(expand=True)

        body = ctk.CTkFrame(row, fg_color="transparent")
        body.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ctk.CTkLabel(body, text="Oplium", font=font(12, "bold"), text_color=C["muted"], anchor="w").pack(anchor="w")
        label = ctk.CTkLabel(
            body, text=text, font=font(14), text_color=C["text"], justify="left", anchor="w",
            wraplength=self.wrap,
        )
        label.pack(anchor="w", pady=(2, 4))

        if sources:
            src = ctk.CTkFrame(body, fg_color="transparent")
            src.pack(anchor="w", pady=(2, 4))
            ctk.CTkLabel(src, text="Sources", font=font(11), text_color=C["faint"]).pack(anchor="w")
            for i, s in enumerate(sources, 1):
                host = urlparse(s["url"]).netloc.replace("www.", "")
                link = ctk.CTkLabel(
                    src, text=f"[{i}]  {s['title'][:60]}  ·  {host}", font=font(11, underline=True),
                    text_color=C["link"], cursor="hand2", anchor="w",
                )
                link.pack(anchor="w")
                link.bind("<Button-1>", lambda e, u=s["url"]: webbrowser.open(u))

        if not live:
            copy = ctk.CTkButton(
                body, text="Copy", width=56, height=24, corner_radius=6, fg_color="transparent",
                hover_color=C["card"], text_color=C["faint"], font=font(11),
            )
            copy.configure(command=lambda t=text, b=copy: self._copy(t, b))
            copy.pack(anchor="w")
        return label

    def _copy(self, text, button):
        self.clipboard_clear()
        self.clipboard_append(text)
        button.configure(text="Copied")
        self.after(1500, lambda: button.winfo_exists() and button.configure(text="Copy"))

    # ----- live (streaming) card ------------------------------------------- #
    def _render_live_card(self):
        self.live_label = self._assistant_card(self._live_display(0), [], live=True)
        self._animate_thinking(0)

    def _live_display(self, step):
        if self.live_text:
            return self.live_text
        return f"{self.live_status}{'.' * (step % 4)}"

    def _animate_thinking(self, step):
        if not self.generating or self.live_text or self.live_label is None:
            return
        try:
            self.live_label.configure(text=self._live_display(step))
        except tk.TclError:
            return
        self.after(400, lambda: self._animate_thinking(step + 1))

    # ----- engine callbacks (always on the UI thread) ----------------------- #
    def on_generation_start(self, chat_id):
        self.generating = True
        self.generating_chat = chat_id
        self.live_text = ""
        self.live_status = "Thinking"
        self.send_btn.configure(text="Stop", fg_color=C["danger"], hover_color="#dc2626", text_color="#ffffff")
        self.refresh_message_stream()

    def set_live_status(self, chat_id, status):
        self.live_status = status

    def on_stream(self, chat_id, text):
        self.live_text = text
        if self.live_label is not None and chat_id == self.current_id:
            self.live_label.configure(text=text)
            self._scroll_bottom()

    def on_generation_done(self, chat_id, text, sources, error):
        self.generating = False
        self.generating_chat = None
        self.live_label = None
        self.send_btn.configure(
            text="Send", fg_color=C["accent"], hover_color=C["accent_hover"], text_color=C["accent_text"]
        )
        chat = self.chats.get(chat_id)
        if chat is not None:
            if text:
                chat["messages"].append({"role": "assistant", "content": text, "sources": sources})
            if error:
                chat["messages"].append({"role": "system", "content": f"Something went wrong: {error}"})
            self.save_chats()
        if chat_id == self.current_id:
            self.refresh_message_stream()

    def on_model_loading(self, model_id):
        self.set_status(f"Loading {self.model_title(model_id)}…", "busy")
        self._build_models_panel()

    def on_model_ready(self, model_id, device):
        self.settings["last_model"] = model_id
        self.save_settings()
        self.set_status(f"{self.model_title(model_id)} ready · {device.upper()}", "ok")
        self._build_models_panel()

    def on_model_error(self, model_id, message):
        self.set_status("Model failed to load", "error")
        chat = self.chats[self.current_id]
        chat["messages"].append(
            {
                "role": "system",
                "content": f"Could not load {self.model_title(model_id)}: {message}\n"
                "Check your internet connection and that the model name is correct (Models tab).",
            }
        )
        self.refresh_message_stream()
        self._build_models_panel()

    # ----- sending ----------------------------------------------------------- #
    def start_inference_thread(self):
        if self.generating:
            self.engine.stop()
            return
        if not self.engine.model_ready:
            self.set_status("Model is still loading…", "busy")
            return
        prompt = self.user_entry.get("1.0", "end").strip()
        if not prompt:
            return
        self.user_entry.delete("1.0", "end")
        self._resize_input()

        chat = self.chats[self.current_id]
        chat["messages"].append({"role": "user", "content": prompt, "sources": []})
        if chat["title"] == "New chat":
            chat["title"] = prompt[:30] + ("…" if len(prompt) > 30 else "")
        self.save_chats()
        self.render_sidebar_cards()
        self.show_chat_frame()

        params = {
            "max_tokens": self.settings["max_tokens"],
            "temperature": self.settings["temperature"],
            "top_p": self.settings["top_p"],
            "repetition_penalty": self.settings["repetition_penalty"],
            "web_search": bool(self.web_var.get()),
            "web_results": self.settings["web_results"],
            "system_prompt": self.settings["system_prompt"],
        }
        history = [dict(m) for m in chat["messages"]]
        self.on_generation_start(self.current_id)
        threading.Thread(
            target=self.engine.execute_token_math, args=(self.current_id, history, params), daemon=True
        ).start()

    # ----- chat management ---------------------------------------------------- #
    def create_fresh_chat(self):
        # reuse an empty chat instead of piling them up
        for cid, c in self.chats.items():
            if not c["messages"]:
                self.current_id = cid
                break
        else:
            self.current_id = self._new_chat_record()
        self.render_sidebar_cards()
        self.show_chat_frame()
        self.refresh_message_stream()
        self.user_entry.focus()

    def switch_session(self, target):
        self.current_id = target
        self.render_sidebar_cards()
        self.show_chat_frame()
        self.refresh_message_stream()

    def delete_chat(self, cid):
        if self.generating and self.generating_chat == cid:
            self.engine.stop()
        self.chats.pop(cid, None)
        if not self.chats:
            self._new_chat_record()
        if self.current_id not in self.chats:
            self.current_id = list(self.chats.keys())[-1]
        self.save_chats()
        self.render_sidebar_cards()
        self.refresh_message_stream()

    # ------------------------------------------------------------------ #
    # Panel switching
    # ------------------------------------------------------------------ #
    def _hide_all(self):
        for p in (self.chat_panel, self.models_panel, self.settings_panel, self.support_panel):
            p.grid_forget()
        for key, b in self.nav_buttons.items():
            b.configure(fg_color="transparent", text_color=C["muted"])

    def _show(self, name, panel, padded):
        self._hide_all()
        self.current_view = name
        if padded:
            panel.grid(row=0, column=0, sticky="nsew", padx=36, pady=30)
        else:
            panel.grid(row=0, column=0, sticky="nsew")
        if name in self.nav_buttons:
            self.nav_buttons[name].configure(fg_color=C["card"], text_color=C["text"])
        self.render_sidebar_cards()

    def show_chat_frame(self):
        self._show("chat", self.chat_panel, padded=False)

    def show_models_frame(self):
        self._build_models_panel()
        self._show("models", self.models_panel, padded=True)

    def show_settings_frame(self):
        self._show("settings", self.settings_panel, padded=True)

    def show_support_frame(self):
        self._show("support", self.support_panel, padded=True)

    def _panel_header(self, panel, title, subtitle):
        head = ctk.CTkFrame(panel, fg_color="transparent")
        head.pack(fill=tk.X, padx=40, pady=(34, 18))
        ctk.CTkLabel(head, text=title, font=font(22, "bold"), text_color=C["text"]).pack(anchor="w")
        ctk.CTkLabel(head, text=subtitle, font=font(13), text_color=C["muted"]).pack(anchor="w", pady=(4, 0))
        ctk.CTkButton(
            head, text="Back to chat", width=110, height=32, corner_radius=8, fg_color=C["card"],
            hover_color=C["card_hover"], text_color=C["text"], font=font(12), command=self.show_chat_frame,
        ).place(relx=1.0, rely=0.0, anchor="ne")

    # ------------------------------------------------------------------ #
    # Models panel
    # ------------------------------------------------------------------ #
    def _build_models_panel(self):
        panel = self.models_panel
        for child in panel.winfo_children():
            child.destroy()
        self._panel_header(panel, "Models", "Switch the model Oplium runs on. The first load downloads the weights.")

        for title, model_id in MODEL_REGISTRY.items():
            is_active = self.engine.model_ready and model_id == self.engine.active_model_id
            is_loading = self.engine.loading_id == model_id
            row = ctk.CTkFrame(panel, fg_color=C["card"], corner_radius=12, border_width=1,
                               border_color=C["accent"] if is_active else C["border"])
            row.pack(fill=tk.X, padx=40, pady=6)
            info = ctk.CTkFrame(row, fg_color="transparent")
            info.pack(side=tk.LEFT, padx=20, pady=14)
            ctk.CTkLabel(info, text=title, font=font(15, "bold"), text_color=C["text"]).pack(anchor="w")
            ctk.CTkLabel(info, text=model_id, font=font(11), text_color=C["faint"]).pack(anchor="w")
            if is_active:
                ctk.CTkLabel(row, text="Active", font=font(12, "bold"), text_color=C["accent"]).pack(side=tk.RIGHT, padx=22)
            else:
                ctk.CTkButton(
                    row, text="Loading…" if is_loading else "Activate", width=110, height=34, corner_radius=8,
                    fg_color=C["accent"], hover_color=C["accent_hover"], text_color=C["accent_text"],
                    font=font(12, "bold"), state="disabled" if self.engine.loading_id else "normal",
                    command=lambda m=model_id: self.engine.async_mount_brain(m),
                ).pack(side=tk.RIGHT, padx=20)

        ctk.CTkButton(
            panel, text="Add local model folder…", width=200, height=38, corner_radius=8,
            fg_color=C["card"], hover_color=C["card_hover"], text_color=C["text"], font=font(12),
            command=self._add_local_model,
        ).pack(anchor="w", padx=40, pady=(18, 0))

    def _add_local_model(self):
        folder = filedialog.askdirectory(title="Choose a model or LoRA adapter folder")
        if not folder:
            return
        name = os.path.basename(folder.rstrip("/\\")) or folder
        MODEL_REGISTRY[name] = folder
        self.settings.setdefault("custom_models", {})[name] = folder
        self.save_settings()
        self._build_models_panel()

    # ------------------------------------------------------------------ #
    # Settings panel
    # ------------------------------------------------------------------ #
    def _slider(self, parent, label, key, lo, hi, steps, fmt, cast):
        wrap = ctk.CTkFrame(parent, fg_color="transparent")
        wrap.pack(fill=tk.X, padx=40, pady=(6, 10))
        lab = ctk.CTkLabel(wrap, text=f"{label}: {fmt(self.settings[key])}", font=font(13), text_color=C["text"])
        lab.pack(anchor="w")

        def on_change(v):
            self.settings[key] = cast(v)
            lab.configure(text=f"{label}: {fmt(self.settings[key])}")
            self._schedule_save()

        s = ctk.CTkSlider(
            wrap, from_=lo, to=hi, number_of_steps=steps, command=on_change,
            progress_color=C["accent"], button_color=C["accent"], button_hover_color=C["accent_hover"],
        )
        s.set(self.settings[key])
        s.pack(fill=tk.X, pady=(6, 0))

    def _build_settings_panel(self):
        panel = self.settings_panel
        self._panel_header(panel, "Settings", "Tune how Oplium writes. Changes are saved automatically.")
        body = ctk.CTkScrollableFrame(panel, fg_color="transparent", scrollbar_button_color=C["card"])
        body.pack(fill=tk.BOTH, expand=True, padx=(0, 10), pady=(0, 20))

        self._slider(body, "Max reply length (tokens)", "max_tokens", 50, 1024, 974, lambda v: str(int(v)), int)
        self._slider(body, "Creativity (temperature)", "temperature", 0.1, 1.2, 22, lambda v: f"{v:.2f}", lambda v: round(float(v), 2))
        self._slider(body, "Top-p", "top_p", 0.5, 1.0, 50, lambda v: f"{v:.2f}", lambda v: round(float(v), 2))
        self._slider(body, "Repetition penalty", "repetition_penalty", 1.0, 1.5, 50, lambda v: f"{v:.2f}", lambda v: round(float(v), 2))
        self._slider(body, "Web results to use", "web_results", 1, 8, 7, lambda v: str(int(v)), lambda v: int(round(v)))

        web = ctk.CTkFrame(body, fg_color="transparent")
        web.pack(fill=tk.X, padx=40, pady=(10, 6))
        ctk.CTkSwitch(
            web, text="Let Oplium search the web before answering", variable=self.web_var,
            command=self._on_web_toggle, progress_color=C["accent"], font=font(13), text_color=C["text"],
        ).pack(anchor="w")

        ctk.CTkLabel(body, text="System prompt", font=font(13), text_color=C["text"]).pack(anchor="w", padx=40, pady=(18, 4))
        self.system_box = ctk.CTkTextbox(
            body, height=110, fg_color=C["card"], border_width=1, border_color=C["border"],
            text_color=C["text"], font=font(13), wrap="word",
        )
        self.system_box.pack(fill=tk.X, padx=40)
        self.system_box.insert("1.0", self.settings["system_prompt"])
        self.system_box.bind("<FocusOut>", self._save_system_prompt)

    def _save_system_prompt(self, event=None):
        text = self.system_box.get("1.0", "end").strip()
        self.settings["system_prompt"] = text or cfg.DEFAULT_SYSTEM_PROMPT
        self.save_settings()

    # ------------------------------------------------------------------ #
    # Support panel
    # ------------------------------------------------------------------ #
    def _build_support_panel(self):
        panel = self.support_panel
        self._panel_header(panel, "Support", "Questions, bugs or business enquiries.")

        em = ctk.CTkFrame(panel, fg_color=C["card"], corner_radius=12, border_width=1, border_color=C["border"])
        em.pack(fill=tk.X, padx=40, pady=8)
        ctk.CTkLabel(em, text="Email", font=font(12), text_color=C["muted"]).pack(anchor="w", padx=20, pady=(14, 0))
        ctk.CTkLabel(em, text=SUPPORT_EMAIL, font=font(15, "bold"), text_color=C["text"]).pack(anchor="w", padx=20, pady=(2, 14))
        ctk.CTkButton(
            em, text="Write email", width=110, height=32, corner_radius=8, fg_color=C["accent"],
            hover_color=C["accent_hover"], text_color=C["accent_text"], font=font(12, "bold"),
            command=lambda: webbrowser.open(f"mailto:{SUPPORT_EMAIL}"),
        ).place(relx=1.0, rely=0.5, anchor="e", x=-20)

        yt = ctk.CTkFrame(panel, fg_color=C["card"], corner_radius=12, border_width=1, border_color=C["border"])
        yt.pack(fill=tk.X, padx=40, pady=8)
        ctk.CTkLabel(yt, text="YouTube", font=font(12), text_color=C["muted"]).pack(anchor="w", padx=20, pady=(14, 0))
        ctk.CTkLabel(yt, text=SUPPORT_YOUTUBE, font=font(15, "bold"), text_color=C["text"]).pack(anchor="w", padx=20, pady=(2, 14))
        ctk.CTkButton(
            yt, text="Open channel", width=110, height=32, corner_radius=8, fg_color=C["card_hover"],
            hover_color=C["border"], text_color=C["text"], font=font(12, "bold"),
            command=lambda: webbrowser.open(f"https://{SUPPORT_YOUTUBE}"),
        ).place(relx=1.0, rely=0.5, anchor="e", x=-20)

        web = ctk.CTkFrame(panel, fg_color=C["card"], corner_radius=12, border_width=1, border_color=C["border"])
        web.pack(fill=tk.X, padx=40, pady=8)
        ctk.CTkLabel(web, text="Website", font=font(12), text_color=C["muted"]).pack(anchor="w", padx=20, pady=(14, 0))
        ctk.CTkLabel(web, text=SUPPORT_WEBSITE, font=font(15, "bold"), text_color=C["text"]).pack(anchor="w", padx=20, pady=(2, 14))
        ctk.CTkButton(
            web, text="Open website", width=110, height=32, corner_radius=8, fg_color=C["card_hover"],
            hover_color=C["border"], text_color=C["text"], font=font(12, "bold"),
            command=lambda: webbrowser.open(SUPPORT_WEBSITE),
        ).place(relx=1.0, rely=0.5, anchor="e", x=-20)


if __name__ == "__main__":
    app = WobelAIFlagshipPortal()
    app.mainloop()
